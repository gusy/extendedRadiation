%Sample script of the extended radiation model for the US counties 
load county_info.txt;
%load dist_allcounty.mat;%or this can be calculated from the quoted parted
%set the alpha value first;
alpha=1;
county_number=size(county_info,1);

dist_allcounty=zeros(county_number,county_number);
for i=1:county_number
    i
    for j=1:county_number
        if i~=j
            dist_allcounty(i,j)=pos2dist(county_info(i,5),county_info(i,6),county_info(j,5),county_info(j,6),2);
        end
    end
end

O=county_info(:,3);
D=county_info(:,4);
OD_Matrix=zeros(county_number*(county_number-1),6);
line_count=0;
for i=1:county_number
    prop=zeros(county_number,1);
    dist=zeros(county_number,1);
   for j=1:county_number
        if i~=j
            %calculate Sij
            s=0;
            dist(j)=dist_allcounty(i,j);
            index=find(dist_allcounty(i,:)<dist(j)&dist_allcounty(i,:)>0);
            s=s+sum(D(index));
            prop(j)=D(i)^alpha*D(j)^alpha/((s^alpha+D(i)^alpha)*(s^alpha+D(j)^alpha+D(i)^alpha));
        else
            s=0;
            dist(j)=0;
            prop(j)=D(i)^alpha*D(j)^alpha/((s^alpha+D(i)^alpha)*(s^alpha+D(j)^alpha+D(i)^alpha));
        end

    end
    for j=1:county_number
        if i~=j
            line_count=line_count+1;
            OD_Matrix(line_count,1)=i;
            OD_Matrix(line_count,2)=j;
            OD_Matrix(line_count,3)=O(i)*prop(j)/sum(prop);
            OD_Matrix(line_count,4)=dist(j);
            OD_Matrix(line_count,5)=O(i);
            OD_Matrix(line_count,6)=D(j);
        end
    end
end
%save OD_Matrix  OD_Matrix




                    