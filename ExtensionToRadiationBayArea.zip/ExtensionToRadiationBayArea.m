%extended radiation model
norm_num=1000000; %enter the desired total trip number here
alpha=0.85; % the alpha value for the extended radiation model
%load the distance matrix, population and POI distribution
load input_data.mat;
[msf,nsf]=size(dist_cell);
O=pop_100; %population representing generation
D=tower_POI100; %POI representing attraction
%normalize to the desired sum
sumD=sum(D);
sumO=sum(O);
D=D.*norm_num./sumD;
O=O.*norm_num./sumO;
%Initialize the output OD matrix
OD_OUTPUT=zeros(msf*(msf-1),6);
OD_OUTPUT_num=0;
for i=1:msf
    prop=zeros(msf,1);
    dist=zeros(msf,1);
    for j=1:msf
        if i~=j
            %calculate Sij
            s=0;
            dist(j)=dist_cell(i,j);
            index=find(dist_cell(i,:)<dist(j)&dist_cell(i,:)>0);
            s=s+sum(D(index));
            prop(j)=D(i)*D(j)^alpha/((s^alpha+D(i))*(s^alpha+D(j)^alpha+D(i)));
        end
    end
    for j=1:msf
        if i~=j
            OD_OUTPUT_num=OD_OUTPUT_num+1;
            OD_OUTPUT(OD_OUTPUT_num,1)=i;
            OD_OUTPUT(OD_OUTPUT_num,2)=j;
            OD_OUTPUT(OD_OUTPUT_num,3)=O(i)*prop(j)/sum(prop);
            OD_OUTPUT(OD_OUTPUT_num,4)=dist(j);
            OD_OUTPUT(OD_OUTPUT_num,5)=O(i);
            OD_OUTPUT(OD_OUTPUT_num,6)=D(j);
        end
    end
end
save OD_OUTPUT.mat OD_OUTPUT 



                    